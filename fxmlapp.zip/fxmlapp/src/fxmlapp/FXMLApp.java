
package fxmlapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author HP 15-bs
 */
public class FXMLApp extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here3
        launch(args);
        
    } 

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxmlapp/start.fxml"));
        stage.setScene(new Scene(root));
        
        stage.setTitle("University");
        stage.show();
    }

}
