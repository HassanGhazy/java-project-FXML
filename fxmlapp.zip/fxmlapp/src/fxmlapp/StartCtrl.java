/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp;

import java.awt.Button;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author HP 15-bs
 */
public class StartCtrl implements Initializable{

    Navigation nav = new Navigation();
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
    }
    @FXML public AnchorPane root;
   
    public void nav_AddSec(){
        nav.navTo(root, nav.fxmladdsec);
    }
    
    public void nav_lec(){
        nav.navTo(root, nav.fxmllecturestimes);
    }
}
