/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author HP 15-bs
 */
public class AddSecCtrl implements Initializable{

    Navigation nav = new Navigation();
    DBModel db = new DBModel();

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        init_comb();

    }
    
    
    @FXML AnchorPane rootPane;
    @FXML ComboBox course_id;
    @FXML ComboBox building;
    @FXML ComboBox room;
    @FXML ComboBox year;
    @FXML ComboBox semester;
    @FXML ComboBox time_slot;
    public void nav_back(){
        nav.navTo(rootPane, nav.fxmlstart);
    }
    
    public void load_rooms(){
        if(building.getValue()!=null)
    room.setItems(FXCollections.observableArrayList(db.getABuildingRooms(building.getValue().toString())));
 
    }
    
    public void add_sec(){
        if(course_id.getValue()!=null && building.getValue()!=null &&room.getValue()!=null
                && semester.getValue()!=null && year.getValue()!=null && time_slot.getValue()!=null)  {
            
            if(db.insertSection(course_id.getValue().toString(), 
                    building.getValue().toString(), room.getValue().toString(),
                    semester.getValue().toString(), Integer.parseInt(year.getValue().toString()), 
                    time_slot.getValue().toString())){
                course_id.getItems().clear();
                building.getItems().clear();
                room.getItems().clear();
                semester.getItems().clear();
                year.getItems().clear();
                time_slot.getItems().clear();
                init_comb();
            }
        }  else System.err.println("Null Fields");    
    }

    private void init_comb() {
        course_id.setItems(FXCollections.observableArrayList(db.getCourseIDs()));
        building.setItems(FXCollections.observableArrayList(db.getBuildings()));
        
        List <Integer> years = IntStream.rangeClosed(Integer.parseInt(Objects.requireNonNull("2000")), 
                Integer.parseInt(Objects.requireNonNull("2030"))).boxed().collect(Collectors.toList());
         year.setItems(FXCollections.observableList(years));
         
         ArrayList <String> sems = new ArrayList<>();
         sems.add("Spring");
         sems.add("Fall");
         sems.add("Summer");
         sems.add("Winter");
         
         semester.setItems(FXCollections.observableArrayList(sems));
         
         ArrayList <String> times = new ArrayList<>();
         for(char ch : "ABCDEFGH".toCharArray()){
             times.add(ch+"");
         }

        time_slot.setItems(FXCollections.observableArrayList(times));
    }
    
    
}
