/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;




/**
 *
 * @author HP 15-bs
 */
public class Navigation {
    public final String fxmlstart = "/fxmlapp/start.fxml";
    public final String fxmladdsec = "/fxmlapp/addsection.fxml";
    public final String fxmllecturestimes = "/fxmlapp/lecturestimes.fxml";
    
    
    public void navTo(Parent rootPane, String path){
        try {
            Parent root = FXMLLoader.load(getClass().getResource(path));
            rootPane.getScene().setRoot(root);
        } catch (IOException ex) {
            Logger.getLogger(Navigation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
