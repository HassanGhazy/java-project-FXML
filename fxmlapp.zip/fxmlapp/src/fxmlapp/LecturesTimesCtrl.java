/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Abeer Jihad
 */
public class LecturesTimesCtrl implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       course_id.setCellValueFactory( new PropertyValueFactory<LectureTime, String>("course_id"));
       course_title.setCellValueFactory(new PropertyValueFactory<LectureTime, String>("Course_title"));
       building.setCellValueFactory(new PropertyValueFactory<LectureTime, String>("Building"));
       room_number.setCellValueFactory(new PropertyValueFactory<LectureTime, String>("Room_number"));
      time_slot.setCellValueFactory(new PropertyValueFactory<LectureTime, String>("Time_slot"));
    }
    DBModel db = new DBModel();
    Navigation nav = new Navigation();
    
    @FXML
     SplitPane root;
    @FXML
     TextField id;    
    @FXML
     TextField name;
    @FXML
     TextField dept;
    @FXML
     ComboBox year;
    @FXML
     ComboBox sem;
    @FXML
     CheckBox student;
    
   
    @FXML
     TableView time_table;
    @FXML
    TableColumn<LectureTime,String> course_id; 
    
     @FXML
    TableColumn<LectureTime,String> course_title; 
     
      @FXML
    TableColumn<LectureTime,String> building;
       @FXML
    TableColumn<LectureTime,String> room_number; 
        @FXML
    TableColumn<LectureTime,String> time_slot; 
    
    public void close(){
        nav.navTo(root, nav.fxmlstart);
    }
    
   public void onIDEnter(){
        if(!id.getText().equals("")){
            if(student.isSelected()){
               name.setText(db.getStdName(id.getText()));
                dept.setText(db.getStdDept(id.getText()));
                year.setItems(FXCollections.observableArrayList(db.getStdYears(id.getText())));
            }
            else{
              name.setText(db.getInstructorName(id.getText()));
                dept.setText(db.getInstructorDept(id.getText()));
                year.setItems(FXCollections.observableArrayList(db.getInstructorYears(id.getText())));  
            }
        }
    }
    
    public void upCombSems(){
        if(year.getValue() !=null){
            if(student.isSelected()){
                sem.setItems(FXCollections.observableArrayList(db.getStdSems(id.getText(), 
                        Integer.parseInt(year.getValue().toString()))));
            } else {
                sem.setItems(FXCollections.observableArrayList(db.getInstructorSems(id.getText(), 
                        Integer.parseInt(year.getValue().toString()))));
            }
        }
    }
    
    public void viewTimes(){
        if(id.getText()!=null && sem.getValue()!=null && year.getValue()!=null){
            if(student.isSelected()){
                time_table.setItems(FXCollections.observableArrayList(db.getStdLectures(id.getText(), sem.getValue().toString(),
                        Integer.parseInt(year.getValue().toString()))));
            } else 
                 time_table.setItems(FXCollections.observableArrayList(db.getInstructorLectures(id.getText(), sem.getValue().toString(),
                        Integer.parseInt(year.getValue().toString()))));
        } else System.out.println("Null Fields");
    }
}
